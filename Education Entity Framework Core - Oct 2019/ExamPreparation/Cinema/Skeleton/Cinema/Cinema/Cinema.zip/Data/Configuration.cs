﻿namespace Cinema.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-1SHT5A0\SQLEXPRESS;Database=Cinema;Trusted_Connection=True";
    }
}
