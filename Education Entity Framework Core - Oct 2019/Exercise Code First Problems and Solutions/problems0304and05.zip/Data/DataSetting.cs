﻿namespace P03_SalesDatabase.Data
{
    static class DataSetting
    {
        internal static string DefaultConnection
            = @"Server=DESKTOP-1SHT5A0\SQLEXPRESS; Database=SalesDatabase; Integrated Security = true";
    }
}
