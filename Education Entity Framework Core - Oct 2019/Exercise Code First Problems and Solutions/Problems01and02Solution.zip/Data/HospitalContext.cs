﻿using JetBrains.Annotations;
using Microsoft.EntityFrameworkCore;
using P01_HospitalDatabase.Data.Models;
using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public class HospitalContext : DbContext
    {
        public HospitalContext(DbContextOptions options)
            : base(options)
        {
        }

        protected HospitalContext()
        {
        }

        public DbSet<Patient> Patients { get; set; }

        public DbSet<Diagnose> Diagnoses { get; set; }

        public DbSet<Medicament> Medicaments { get; set; }

        public DbSet<PatientMedicament> PatientMedicaments { get; set; }

        public DbSet<Visitation> Visitations { get; set; }

        public DbSet<Doctor> Doctor { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            if (!optionsBuilder.IsConfigured)
            {
                optionsBuilder
                    .UseSqlServer(DataSetting
                                 .DefaultConnection);
            }

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Patient>(entity =>
            {
                entity.HasKey(e => e.PatientId);

                entity.Property(e => e.FirstName)
                      .HasMaxLength(50)
                      .IsUnicode(true)
                      .IsRequired(true);

                entity.Property(e => e.LastName)
                      .HasMaxLength(50)
                      .IsUnicode(true)
                      .IsRequired(true);

                entity.Property(e => e.Address)
                      .HasMaxLength(250)
                      .IsRequired(false)
                      .IsUnicode(true);

                entity.Property(e => e.Email)
                      .HasMaxLength(80)
                      .IsRequired(true)
                      .IsUnicode(false);

                entity.Property(e => e.HasInsurance)
                      .HasDefaultValue(false)
                      .IsRequired(true);

            });


            modelBuilder.Entity<Visitation>(entity =>
            {
                entity.HasKey(e => e.VisitationId);

                entity.Property(e => e.Date)
                      .IsRequired(true);

                entity.Property(e => e.Comments)
                      .HasMaxLength(250)
                      .IsRequired(true)
                      .IsUnicode(true);

                entity.Property(e => e.PatientId)
                      .IsRequired(true);

            });


            modelBuilder.Entity<Doctor>(entity =>
            {
                entity.HasKey(e => e.DoctorId);

                entity.Property(e => e.Name)
                      .IsRequired(true)
                      .HasMaxLength(100)
                      .IsUnicode(true); ;

                entity.Property(e => e.Specialty)
                      .IsRequired(true)
                      .IsUnicode(true)
                      .HasMaxLength(100);
            });


            modelBuilder.Entity<Diagnose>(entity =>
            {
                entity.HasKey(e => e.DiagnoseId);

                entity.Property(e => e.Name)
                      .IsRequired(true)
                      .IsUnicode(true)
                      .HasMaxLength(50);

                entity.Property(e => e.Comments)
                      .IsRequired(false)
                      .HasMaxLength(250)
                      .IsUnicode(true);

                entity.Property(e => e.PatientId)
                      .IsRequired(true);

            });


            modelBuilder.Entity<Medicament>(entity =>
            {
                entity.HasKey(e => e.MedicamentId);

                entity.Property(e => e.Name)
                      .IsRequired(true)
                      .IsUnicode(true)
                      .HasMaxLength(50);

            });

            // mapping table ??? remove this one?

            //modelBuilder.Entity<PatientMedicament>(entity =>
            //{
            //    entity.HasKey(e => e.MedicamentId);
            //    entity.HasKey(e => e.PatientId);

            //});

            // one doctor has many visitations , one visitation has one doctor 

            modelBuilder.Entity<Visitation>()
                .HasOne(v => v.Doctor)
                .WithMany(d => d.Visitations)
                .HasForeignKey(v => v.DoctorId);

            // one patient has many visitations , one visitation has one patient

            modelBuilder.Entity<Visitation>()
                .HasOne(v => v.Patient)
                .WithMany(p => p.Visitations)
                .HasForeignKey(v => v.PatientId);

            // one patient can have many diagnoses , one diagnose can have many patients 

            modelBuilder.Entity<Diagnose>()
                .HasOne(d => d.Patient)
                .WithMany(p => p.Diagnoses)
                .HasForeignKey(d => d.PatientId);


            //one patient many medicaments , one medicament has many patients 

            modelBuilder.Entity<PatientMedicament>()
                .HasKey(pm => new
                {
                    pm.MedicamentId,
                    pm.PatientId
                });

            modelBuilder.Entity<PatientMedicament>()
                .HasOne(pm => pm.Patient)
                .WithMany(pm => pm.Prescriptions)
                .HasForeignKey(pm => pm.PatientId);

            modelBuilder.Entity<PatientMedicament>()
                .HasOne(pm => pm.Medicament)
                .WithMany(pm => pm.Prescriptions)
                .HasForeignKey(pm => pm.MedicamentId); 



        }

    }
}
