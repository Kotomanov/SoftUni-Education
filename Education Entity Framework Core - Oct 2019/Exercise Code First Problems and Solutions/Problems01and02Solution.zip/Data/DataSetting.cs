﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    static class DataSetting
    {
        public const string DefaultConnection
            = "Server=DESKTOP-1SHT5A0\\SQLEXPRESS; Database=HospitalDb; Integrated Security = true";

    }

}
