﻿using AutoMapper;
using CarDealer.Dtos.Export;
using CarDealer.Dtos.Import;
using CarDealer.Models;
using System.Linq; 

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            // Import DTOs

            this.CreateMap<ImportSupplierDto, Supplier>();

            this.CreateMap<ImportPartDto, Part>();

            this.CreateMap<ImportCarDto, Car>();

            this.CreateMap<CarPartImportDto, Part>();

            this.CreateMap<ImportCustomersDto, Customer>();

            // ExportDTOs

            this.CreateMap<Car, CarDistanceDto>();

            this.CreateMap<Car, CarsBMWDto>(); 

            this.CreateMap<Supplier, LocalSuppliersDto>();


            this.CreateMap<Part, PartListDto>();

            this.CreateMap<Car, CarWithListofPartsDto>()
                .ForMember(x=>x.PartsList, y=>y.MapFrom(x=>x.PartCars
                                                            .Select(pc=>pc.Part)));

            this.CreateMap<Customer, TotalSaleDto>();
        }
    }
}
