﻿using System;

namespace CarDealer.Dtos.Import
{
    internal class XMLTypeAttribute : Attribute
    {
    }
}