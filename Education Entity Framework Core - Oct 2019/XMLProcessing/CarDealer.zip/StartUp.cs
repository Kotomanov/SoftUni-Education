﻿using AutoMapper;
using AutoMapper.QueryableExtensions;
using CarDealer.Data;
using CarDealer.Dtos.Export;
using CarDealer.Dtos.Import;
using CarDealer.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace CarDealer
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Mapper.Initialize(cfg => cfg.AddProfile<CarDealerProfile>());

            using (var context = new CarDealerContext())
            {
                //context.Database.EnsureDeleted();
                //context.Database.EnsureCreated();

                //string filePath = File.ReadAllText(@"D:\Miro\SoftUni\Materials\EntityFrameworkCore\HomeWorks\XMLProcessing\CarDealer\CarDealer - Skeleton\CarDealer\Datasets\sales.xml");

                var result = GetSalesWithAppliedDiscount(context);  //, filePath);

                Console.WriteLine(result);
            }
        }

        // Import
        public static string ImportSuppliers(CarDealerContext context, string inputXml)
        {
            ImportSupplierDto[] supplierDtos;

            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(ImportSupplierDto[]),
                  new XmlRootAttribute("Suppliers")); // this is the root


            using (var reader = new StringReader(inputXml))
            {
                supplierDtos = (ImportSupplierDto[])xmlSerializer.Deserialize(reader);
            }

            var suppliers = Mapper.Map<Supplier[]>(supplierDtos);

            context.Suppliers.AddRange(suppliers);

            context.SaveChanges();

            return $"Successfully imported {suppliers.Length}";
        }

        public static string ImportParts(CarDealerContext context, string inputXml)
        {
            ImportPartDto[] importPartDtos;

            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(ImportPartDto[]),
                  new XmlRootAttribute("Parts"));


            using (var reader = new StringReader(inputXml))
            {
                importPartDtos = ((ImportPartDto[])xmlSerializer.Deserialize(reader))
                                                                .Where(p => context
                                                                            .Suppliers
                                                                            .Any(s => s.Id == p.SupplierId))
                                                                .ToArray();
                //cast as it returns object 
            }

            var parts = Mapper.Map<Part[]>(importPartDtos);
            // to insert to the DB the data

            context.Parts.AddRange(parts);

            context.SaveChanges();

            return $"Successfully imported {parts.Length}";
        }

        public static string ImportCars(CarDealerContext context, string inputXml)
        {


            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(ImportCarDto[]),
                  new XmlRootAttribute("Cars"));

            ImportCarDto[] importedCars;

            using (var reader = new StringReader(inputXml))
            {
                importedCars = (ImportCarDto[])xmlSerializer.Deserialize(reader);

                var cars = new List<Car>();
                var carParts = new List<PartCar>();

                foreach (var carDto in importedCars)
                {
                    var car = new Car()
                    {
                        Make = carDto.Make,
                        Model = carDto.Model,
                        TravelledDistance = carDto.TravelledDistance
                    };



                    var parts = carDto.PartIds
                                       .Where(pdto => context.Parts
                                                             .Any(p => p.Id == pdto.PartId))
                                       .Select(p => p.PartId)
                                       .Distinct();


                    foreach (var partId in parts)
                    {
                        PartCar partCar = new PartCar()
                        {
                            PartId = partId,
                            Car = car
                        };

                        carParts.Add(partCar);
                    }

                    cars.Add(car);

                }

                context.Cars.AddRange(cars);
                context.PartCars.AddRange(carParts);
                context.SaveChanges();

                return $"Successfully imported {cars.Count}";
            }

        }

        public static string ImportCustomers(CarDealerContext context, string inputXml)
        {
            //Customers

            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(ImportCustomersDto[]),
                  new XmlRootAttribute("Customers"));

            ImportCustomersDto[] customerDtos;

            using (var reader = new StringReader(inputXml))
            {

                customerDtos = (ImportCustomersDto[])xmlSerializer.Deserialize(reader);

                var customers = Mapper.Map<Customer[]>(customerDtos);

                context.Customers.AddRange(customers);
                context.SaveChanges();

                return $"Successfully imported {customers.Length}";
            }


        }

        public static string ImportSales(CarDealerContext context, string inputXml)
        {

            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(ImportSalesDto[]),
                  new XmlRootAttribute("Sales"));

            ImportSalesDto[] importsales;

            using (var reader = new StringReader(inputXml))
            {
                importsales = (ImportSalesDto[])xmlSerializer.Deserialize(reader);

                List<Sale> salesList = new List<Sale>();

                foreach (var item in importsales.Where(s => context.Cars.Any(c => c.Id == s.CarId)))
                {
                    Sale sale = new Sale()
                    {
                        CarId = item.CarId,
                        CustomerId = item.CustomerId,
                        Discount = item.Discount

                    };

                    salesList.Add(sale);
                }


                context.Sales.AddRange(salesList);
                context.SaveChanges();

                return $"Successfully imported {salesList.Count}";

            }

        }

        // Export 

        public static string GetCarsWithDistance(CarDealerContext context)
        {
            StringBuilder sb = new StringBuilder();


            var cars = context.Cars
                              .Where(c => c.TravelledDistance > 2000000)
                              .ProjectTo<CarDistanceDto>()
                              .OrderBy(c => c.Make)
                              .ThenBy(c => c.Model)
                              .Take(10)
                              .ToArray();

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(CarDistanceDto[]),
                                          new XmlRootAttribute("cars"));

            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, cars, namespaces);
            }

            return sb.ToString().TrimEnd();




        }

        public static string GetCarsFromMakeBmw(CarDealerContext context)
        {
            StringBuilder sb = new StringBuilder();

            var cars = context.Cars
                              .Where(c => c.Make == "BMW")
                              .ProjectTo<CarsBMWDto>()
                              .OrderBy(c => c.Model)
                              .ThenByDescending(c => c.TravelledDistance)
                              .ToArray();


            XmlSerializer xmlSerializer = new XmlSerializer(typeof(CarsBMWDto[]),
                                          new XmlRootAttribute("cars"));

            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, cars, namespaces);
            }

            return sb.ToString().TrimEnd();

        }


        public static string GetLocalSuppliers(CarDealerContext context)
        {
            StringBuilder sb = new StringBuilder();

            var localSuppliers = context.Suppliers
                                        .Where(s => !s.IsImporter)
                                        .ProjectTo<LocalSuppliersDto>()
                                        .ToArray();

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(LocalSuppliersDto[]),
                                          new XmlRootAttribute("suppliers"));

            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, localSuppliers, namespaces);
            }

            return sb.ToString().TrimEnd();
        }

        public static string GetCarsWithTheirListOfParts(CarDealerContext context)
        {
            StringBuilder sb = new StringBuilder();

            var carsWithParts = context.Cars
                                        .ProjectTo<CarWithListofPartsDto>()
                                        .OrderByDescending(c => c.TravelledDistance)
                                        .ThenBy(c => c.Model)
                                        .Take(5)
                                        .ToArray();

            foreach (var car in carsWithParts)
            {
                car.PartsList = car.PartsList.OrderByDescending(p => p.Price).ToArray();
            }

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(CarWithListofPartsDto[]),
                                          new XmlRootAttribute("cars"));

            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, carsWithParts, namespaces);
            }

            return sb.ToString().TrimEnd();

        }

        public static string GetTotalSalesByCustomer(CarDealerContext context)
        {
            StringBuilder sb = new StringBuilder();

            var sales = context.Customers
                .Where(c => c.Sales.Count() > 0)
                .Select(s => new TotalSaleDto
                {
                    Name = s.Name,
                    SalesCount = s.Sales.Count,
                    SalesSum = s.Sales.Sum(ss => ss.Car.PartCars.Sum(pc => pc.Part.Price))
                })
                .OrderByDescending(c => c.SalesSum)
                .ToArray();


            XmlSerializer xmlSerializer = new XmlSerializer(typeof(TotalSaleDto[]),
                                         new XmlRootAttribute("cars"));

            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, sales, namespaces);
            }

            return sb.ToString().TrimEnd();

        }

        public static string GetSalesWithAppliedDiscount(CarDealerContext context)
        {
            StringBuilder sb = new StringBuilder();

            //todo

            var sales = context.Sales
                               .Select(s=> new DiscountSalesDtoExport 
                               {
                                   carExport = new CarExportDto
                                   {
                                       Make= s.Car.Make,
                                       Model = s.Car.Model,
                                      TravelledDistance = s.Car.TravelledDistance, 
                                   },
                                   Discount = s.Discount,
                                   Name = s.Customer.Name,
                                   Price = s.Car.PartCars.Sum(pc=>pc.Part.Price),
                                   DiscountedPrice =  s.Car.PartCars.Sum(pc => pc.Part.Price) * (1 - s.Discount / 100)
                               })
                               .ToArray(); 


            XmlSerializer xmlSerializer = new XmlSerializer(typeof(DiscountSalesDtoExport[]),
                                         new XmlRootAttribute("sales"));

            var namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, sales, namespaces);
            }

            return sb.ToString().TrimEnd();
        }



    }
}