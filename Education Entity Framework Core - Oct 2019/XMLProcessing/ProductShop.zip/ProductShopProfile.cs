﻿using AutoMapper;
using ProductShop.Dtos.Import;
using ProductShop.Models;

namespace ProductShop
{
    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
            // Import DTOs

            this.CreateMap<UsersImportDto, User>();

            this.CreateMap<ProductsImportDto, Product>();

            this.CreateMap<CategoriesImportDto, Category>();

            this.CreateMap<CategoryProductImportDto, CategoryProduct>();

            // ExportDTOs

        }
    }
}
