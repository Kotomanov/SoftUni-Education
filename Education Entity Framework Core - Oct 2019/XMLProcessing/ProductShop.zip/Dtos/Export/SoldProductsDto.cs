﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml.Serialization;

namespace ProductShop.Dtos.Export
{
    [XmlType("SoldProducts")] //OK
    public class SoldProductsDto
    {
        [XmlElement("count")]
        public int ProductsCountSoldProducts { get; set; }


        [XmlArray("products")]
        public ProductSoldExportDto[] ProductsListInnerArray { get; set; }
    }
}
