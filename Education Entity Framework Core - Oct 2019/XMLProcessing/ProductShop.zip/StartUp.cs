﻿using AutoMapper;
using ProductShop.Data;
using ProductShop.Dtos.Export;
using ProductShop.Dtos.Import;
using ProductShop.Models;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Xml.Serialization;

namespace ProductShop
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Mapper.Initialize(cfg => cfg.AddProfile<ProductShopProfile>());

            using (var context = new ProductShopContext())
            {

                //context.Database.EnsureDeleted();
                //context.Database.EnsureCreated();

                //string filePath = File.ReadAllText(@"D:\Miro\SoftUni\Materials\EntityFrameworkCore\HomeWorks\XMLProcessing\ProductShop\ProductShop - Skeleton\ProductShop\Datasets\categories-products.xml");

                var result = GetCategoriesByProductsCount(context); //, filePath);

                Console.WriteLine(result);

            }
        }

        //Import
        public static string ImportUsers(ProductShopContext context, string inputXml)
        {

            UsersImportDto[] importedUsers;

            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(UsersImportDto[]),
                  new XmlRootAttribute("Users"));

            using (var reader = new StringReader(inputXml))
            {
                importedUsers = (UsersImportDto[])xmlSerializer.Deserialize(reader);
            }

            var users = Mapper.Map<User[]>(importedUsers);

            context.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Length}";
        }

        public static string ImportProducts(ProductShopContext context, string inputXml)
        {
            ProductsImportDto[] productsImported;

            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(ProductsImportDto[]),
                  new XmlRootAttribute("Products"));

            using (var reader = new StringReader(inputXml))
            {
                productsImported = (ProductsImportDto[])xmlSerializer.Deserialize(reader);

                var products = Mapper.Map<Product[]>(productsImported);

                context.Products.AddRange(products);
                context.SaveChanges();

                return $"Successfully imported {products.Length}";
            }

        }

        public static string ImportCategories(ProductShopContext context, string inputXml)
        {
            CategoriesImportDto[] categoriesImported;

            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(CategoriesImportDto[]),
                  new XmlRootAttribute("Categories"));

            using (var reader = new StringReader(inputXml))
            {
                categoriesImported = (CategoriesImportDto[])xmlSerializer.Deserialize(reader);

                var categoriesList = new List<Category>();

                foreach (var item in categoriesImported.Where(ci => ci.Name != null))
                {
                    Category category = new Category()
                    {
                        Name = item.Name

                    };

                    categoriesList.Add(category);
                }

                context.Categories.AddRange(categoriesList);
                context.SaveChanges();
                return $"Successfully imported {categoriesList.Count}";
            }


        }

        public static string ImportCategoryProducts(ProductShopContext context, string inputXml)
        {
            CategoryProductImportDto[] importedProductsAndcategories;

            XmlSerializer xmlSerializer
                = new XmlSerializer(typeof(CategoryProductImportDto[]),
                  new XmlRootAttribute("CategoryProducts"));

            using (var reader = new StringReader(inputXml))
            {
                importedProductsAndcategories = (CategoryProductImportDto[])xmlSerializer.Deserialize(reader);

                List<CategoryProduct> productCategoryList = new List<CategoryProduct>();

                foreach (var item in importedProductsAndcategories.Where(ip => context.Categories.Any(c => c.Id == ip.CategoryId)).Where(ip => context.Products.Any(p => p.Id == ip.ProductId)))
                {
                    CategoryProduct categoryProduct = new CategoryProduct()
                    {
                        CategoryId = item.CategoryId,
                        ProductId = item.ProductId
                    };
                    productCategoryList.Add(categoryProduct);
                }

                context.CategoryProducts.AddRange(productCategoryList);
                context.SaveChanges();


                return $"Successfully imported {productCategoryList.Count}";


            }





        }

        //Export

        public static string GetProductsInRange(ProductShopContext context)
        {

            StringBuilder sb = new StringBuilder();

            var products = context.Products
                                  .Where(p => p.Price >= 500 && p.Price <= 1000)
                                  .Select(p => new ProductsInRangeDto
                                  {
                                      Name = p.Name,
                                      Price = p.Price,
                                      BuyerFullName = p.Buyer.FirstName + " " + p.Buyer.LastName

                                  })
                                  .OrderBy(p => p.Price)
                                  .Take(10)
                                  .ToArray();

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(ProductsInRangeDto[]),
                                          new XmlRootAttribute("Products"));

            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, products, namespaces);
            }

            return sb.ToString().TrimEnd();

        }

        public static string GetSoldProducts(ProductShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            //
            var users = context.Users
                               .Where(u => u.ProductsSold.Count > 0)
                               .OrderBy(u => u.LastName)
                               .ThenBy(u => u.FirstName)
                               .Select(u => new SoldProductsExportDto
                               {
                                   FirstName = u.FirstName,
                                   LastName = u.LastName,
                                   Products = u.ProductsSold.Select(p => new ProductExportDto
                                   {
                                       Name = p.Name,
                                       Price = p.Price
                                   })
                                   .ToArray()

                               }

                               )
                               .Take(5)
                               .ToArray();


            XmlSerializer xmlSerializer = new XmlSerializer(typeof(SoldProductsExportDto[]),
                                          new XmlRootAttribute("Users"));

            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, users, namespaces);
            }

            return sb.ToString().TrimEnd();


        }

        public static string GetCategoriesByProductsCount(ProductShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            var categories = context.Categories
                                    .Select(c => new CategoryProductExportDto
                                    {
                                        Name = c.Name,
                                        CountOfProducts = c.CategoryProducts.Count(),
                                        AveragePrice = c.CategoryProducts.Sum(cp => cp.Product.Price) / c.CategoryProducts.Count(),
                                        TotalRevenue = c.CategoryProducts.Sum(cp => cp.Product.Price)
                                    }
                                    )
                                    .OrderByDescending(c => c.CountOfProducts)
                                    .ThenBy(c => c.TotalRevenue)
                                    .ToArray();

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(CategoryProductExportDto[]),
                                          new XmlRootAttribute("Categories"));

            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, categories, namespaces);
            }

            return sb.ToString().TrimEnd();

        }

        public static string GetUsersWithProducts(ProductShopContext context)
        {
            StringBuilder sb = new StringBuilder();

            //
            var users = context.Users
                               .Where(u => u.ProductsSold.Count > 0)
                               .OrderByDescending(u => u.ProductsSold.Count)
                               .Select(u => new UsersAndProductExportDto
                               {
                                   FirstName = u.FirstName,
                                   LastName = u.LastName,
                                   Age = u.Age,
                                   ProductsSoldList = new SoldProductsDto
                                   {
                                       ProductsCountSoldProducts = u.ProductsSold.Count,
                                       ProductsListInnerArray =  new ProductExportDto
                                                                      {
                                                                          Name = ps.Name,
                                                                          Price = ps.Price

                                                                      }  
                                                                .OrderByDescending(ps => ps.Price)
                                                                .ToArray()
                                   }

                               })
                               .Take(10)
                               .ToArray();

            var finalCountUsers = new UsProDto
            {
                UsersCount = users.Count(),
                UsersList = users
            };

            XmlSerializer xmlSerializer = new XmlSerializer(typeof(UsProDto[]),
                                        new XmlRootAttribute("Users"));

            XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
            namespaces.Add(string.Empty, string.Empty);

            using (StringWriter writer = new StringWriter(sb))
            {
                xmlSerializer.Serialize(writer, finalCountUsers, namespaces);
            }

            return sb.ToString().TrimEnd();

        }

    }
}