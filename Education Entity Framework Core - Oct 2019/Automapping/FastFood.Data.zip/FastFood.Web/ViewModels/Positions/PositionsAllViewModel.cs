﻿namespace FastFood.Web.ViewModels.Positions
{
    public class PositionsAllViewModel
    {
        public string Name { get; set; }
    }
}
