﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    static class DataBaseAccess
    {

        internal static string DefaultConnection
          = @"Server=DESKTOP-1SHT5A0\SQLEXPRESS; Database=SalesDatabase; Integrated Security = true";
    }
}
