﻿namespace P03_FootballBetting.Data
{
    static class DataConnection
    {
        public const string DefaultConnection
            = "Server=DESKTOP-1SHT5A0\\SQLEXPRESS; Database= FootballBettingDb; Integrated Security = true";
    }
}
